//
//  VenuesApiServices.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import Foundation

class VenuesApiServices {
    var networkManager: NetworkManagerProtocol

    init(networkManager: NetworkManagerProtocol = NetworkManager()) {
        self.networkManager = networkManager
    }

    func getAllVenues(requst: VenueModel) async throws ->  Venues {
        do {
            let resData: Venues = try await networkManager.request(request: requst.urlRequest)
            return resData
        } catch {
            throw error
        }

    }
}
