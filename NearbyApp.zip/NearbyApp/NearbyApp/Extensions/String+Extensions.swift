//
//  String+Extensions.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import Foundation
extension String {
    func toInt() -> Int {
        return Int(self) ?? 0
    }
}

extension Int {
    
    func toString() -> String {
        return String(self)
    }
}


extension Double {
    func toString() -> String {
        return String(self)
    }
}
