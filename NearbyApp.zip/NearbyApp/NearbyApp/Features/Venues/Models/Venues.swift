//
//  Venues.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import Foundation

struct VenueModel: Codable {
    var perPage: Int
    var page: Int
    var lat: Double
    var lon: Double
    var range: String
    var query: String
    
    init(perPage: Int, page: Int, lat: Double, lon: Double, range: String, query: String){
        self.perPage = perPage
        self.page = page
        self.lon = lon
        self.lat = lat
        self.range = range
        self.query = query
    }
}

extension VenueModel: EndPoint {
    var queryItems: [URLQueryItem]? {
        
//        let queryItems = [URLQueryItem(name: "per_page", value: "10"),
//                          URLQueryItem(name: "page", value: "1"),
//                          URLQueryItem(name: "client_id", value: "Mzg0OTc0Njl8MTcwMDgxMTg5NC44MDk2NjY5"),
//                          URLQueryItem(name: "lat", value: "12.971599"),
//                          URLQueryItem(name: "lon", value: "77.594566"),
//                          URLQueryItem(name: "range", value: "12mi"),
//                          URLQueryItem(name: "q", value: "ub")
//                          ]
        
        let queryItems = [URLQueryItem(name: "per_page", value: perPage.toString()),
                          URLQueryItem(name: "page", value: page.toString()),
                          URLQueryItem(name: "client_id", value: "Mzg0OTc0Njl8MTcwMDgxMTg5NC44MDk2NjY5"),
                          URLQueryItem(name: "lat", value: lat.toString()),
                          URLQueryItem(name: "lon", value: lon.toString()),
                          URLQueryItem(name: "range", value: range),
                          URLQueryItem(name: "q", value: query)]
                          
        return queryItems
        
    }
    
    var path: String {
        return "/2/venues"
    }
    
    
    var httpMethod: HttpMethod {
        .get
    }
    
    
}
struct Venues: Codable {
    let venues: [Venue]
    let meta: Meta?
}

// MARK: - Meta
struct Meta: Codable {
    let total, took, page, perPage: Int?
    let geolocation: Geolocation
    
    enum CodingKeys: String, CodingKey {
        case total, took, page
        case perPage = "per_page"
        case geolocation
    }
}

// MARK: - Geolocation
struct Geolocation: Codable {
    let lat, lon: Double
    let city, state, country, postalCode: String
    let displayName: String
    let metroCode: String?
    let range: String
    
    enum CodingKeys: String, CodingKey {
        case lat, lon, city, state, country
        case postalCode = "postal_code"
        case displayName = "display_name"
        case metroCode = "metro_code"
        case range
    }
}

// MARK: - Venue
struct Venue: Codable, Identifiable {
    let state: String?
    let nameV2, postalCode, name: String
    let links: [String]?
    let timezone: String?
    let url: String
    let score: Int
    let location: Location?
    let address: String?
    let country: String?
    let hasUpcomingEvents: Bool
    let numUpcomingEvents: Int
    let city: String
    let slug: String
    let extendedAddress: String?
    let stats: Stats?
    let id, popularity: Int
    let accessMethod: String?
    let metroCode, capacity: Int
    let displayLocation: String?
    
    enum CodingKeys: String, CodingKey {
        case state
        case nameV2 = "name_v2"
        case postalCode = "postal_code"
        case name, links, timezone, url, score, location, address, country
        case hasUpcomingEvents = "has_upcoming_events"
        case numUpcomingEvents = "num_upcoming_events"
        case city, slug
        case extendedAddress = "extended_address"
        case stats, id, popularity
        case accessMethod = "access_method"
        case metroCode = "metro_code"
        case capacity
        case displayLocation = "display_location"
    }
}
struct Location: Codable {
    let lat, lon: Double
}

struct Stats: Codable {
    let eventCount: Int
    
    enum CodingKeys: String, CodingKey {
        case eventCount = "event_count"
    }
}
