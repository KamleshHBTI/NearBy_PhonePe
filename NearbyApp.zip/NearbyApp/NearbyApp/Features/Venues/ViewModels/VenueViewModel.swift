//
//  VenueViewModel.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import Foundation

class VenueViewModel: ObservableObject {
    @Published var venues: [Venue] = []
    var apiService: VenuesApiServices
    @Published var sliderValue: Double = 12
    @Published var searchText = "ub"
    @Published var isSearching = false
    
    init(apiService: VenuesApiServices) {
        self.apiService = apiService
    }

    func getVenus() async {
        let range = sliderValue.toString() + "mi"
        let request = VenueModel(perPage: 10, page: 1, lat: 12.971599, lon: 77.594566, range: range, query: searchText)
        do {
            let resData = try await apiService.getAllVenues(requst: request)
            print(resData)
            DispatchQueue.main.async {
                self.venues = resData.venues
            }
        } catch {

        }
    }
}
