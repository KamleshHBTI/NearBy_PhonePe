//
//  VenueCellView.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import SwiftUI

struct VenueCellView: View {
    
    var venue: Venue
    
    init(venue: Venue) {
        self.venue = venue
    }
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack(alignment: .top) {
                AsyncImage(
                    url: URL(string: venue.url ?? "")!,
                   placeholder: { Text("Loading ...") },
                   image: { Image(uiImage: $0).resizable() }
                )
                .scaledToFit()
                
                VStack(alignment: .leading, spacing: 5) {
                    Text(venue.name)
                        .font(.callout)
                    Text(venue.extendedAddress ?? "")
                        .font(.system(size: 10))
                        .multilineTextAlignment(.leading)
                }
            }
        }
    }
}

struct VenueCellView_Previews: PreviewProvider {
    static var previews: some View {
        VenueCellView(venue: Venue(state: "", nameV2: "", postalCode: "", name: "", links: [], timezone: "", url: "https://seatgeek.com/venues/ubcity/tickets", score: 0, location: Location(lat: 12.9833, lon: 77.5833), address: "", country: "India", hasUpcomingEvents: false, numUpcomingEvents: 0, city: "Bangalore", slug: "high-ultra-lounge", extendedAddress: "Bangalore, India", stats: Stats(eventCount: 0), id: 345461, popularity: 0, accessMethod: "", metroCode: 0, capacity: 0, displayLocation: "Bangalore, India"))
    }
}
