//
//  ContentView.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import SwiftUI

struct VenueListView: View {
    @ObservedObject var viewModel = VenueViewModel(apiService: VenuesApiServices())
    @State private var isActive = false
    
    var body: some View {
        NavigationView {
            VStack {
                List(viewModel.venues) { venue in
                    VenueCellView(venue: venue)
                }
                .navigationTitle("Top Venues")
                .navigationViewStyle(.stack)
                .listStyle(.plain)
                Spacer()
                Slider(value: $viewModel.sliderValue, in: 0...10)
                    .onChange(of: viewModel.sliderValue) { newValue in
                        Task {
                            await viewModel.getVenus()
                        }
                    }
                    .padding()
            }
            .searchable(text: $viewModel.searchText)
            .onChange(of: viewModel.searchText) { newValue in
                Task {
                    await viewModel.getVenus()
                }
            }
            .task {
                await viewModel.getVenus()
            }
        }
    }
    
    func getVenus() async {
        await viewModel.getVenus()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        VenueListView()
    }
}
