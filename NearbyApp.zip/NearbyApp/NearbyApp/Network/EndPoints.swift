//
//  EndPoints.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import Foundation

import Foundation

enum HttpMethod: String {
    case post = "POST"
    case get = "GET"
    case delete = "DELETE"
    case put = "PUT"
}

struct Header {
    let key: String
    let value: String

    init(key: String, value: String) {
        self.key = key
        self.value = value
    }
}

protocol EndPoint {
    var path: String { get }
    var host: String { get }
    var urlRequest: URLRequest { get }
    var queryItems: [URLQueryItem]? { get }
    var httpMethod: HttpMethod { get }
    var httpBody: Data? { get }
    var headers: [Header] { get }
}

extension EndPoint where Self: Codable {

    var url: URL {
        var components = URLComponents()
        components.scheme = "https"
        components.host = host
        components.path = path
        components.queryItems = httpMethod == .get ? queryItems : nil
        return components.url!
    }

    var urlRequest: URLRequest {
        var request = URLRequest(url: self.url)
        request.httpMethod = self.httpMethod.rawValue
        headers.forEach {
            request.addValue($0.value, forHTTPHeaderField: $0.key)
        }
        request.httpBody = httpMethod == .get ? nil : httpBody
        return request
    }

    var httpBody: Data? {
        do {
            return try JSONEncoder().encode(self)
        } catch {
            return nil
        }
    }

    
}

extension EndPoint {
    var commonHeaders: [Header] {
        let headers: [Header] = [.init(key: "Content-Type", value: "application/json")
                                 ]
        return headers
    }
}

extension EndPoint {
    var host: String {
        return "api.seatgeek.com"
    }

    var headers: [Header] {
        commonHeaders
    }

    var httpMethod: HttpMethod {
        return .post
    }
}
