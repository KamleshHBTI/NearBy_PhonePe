//
//  NetworkManager.swift
//  NearbyApp
//
//  Created by parth on 25/11/23.
//

import Foundation

public enum ApiError: Error {
    case invalidUrl
    case invalidStatusCode(Int)
    case invalidResponse
    case invalidData
    case unableToComplte(Error)
}

protocol NetworkManagerProtocol {
    var urlSession: URLSession { get set }
    func request<T: Decodable>(request: URLRequest) async throws -> T
}

class NetworkManager: NetworkManagerProtocol {
    var urlSession: URLSession

    init(urlSession: URLSession = URLSession(configuration: .default)) {
        self.urlSession = urlSession
    }

    func request<T: Decodable>(request: URLRequest) async throws -> T  {
        guard request.url != nil else {
            throw ApiError.invalidUrl
        }
        print("request.url!------>", request.url!)
        print(request.allHTTPHeaderFields)
        let (data, response) = try await urlSession.data(for: request)
        guard let urlResponse = response as? HTTPURLResponse else {
            throw ApiError.invalidResponse
        }
        if !(200..<300).contains(urlResponse.statusCode) {
            throw ApiError.invalidStatusCode(urlResponse.statusCode)
        }

        do {
            return try! JSONDecoder().decode(T.self, from: data)
        } catch(let error) {
            throw ApiError.unableToComplte(error)
        }
    }
}
